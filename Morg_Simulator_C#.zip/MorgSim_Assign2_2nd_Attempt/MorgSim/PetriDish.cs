﻿// Derek Edwards
// PetriDish class: creates game board and maintains a list of all living morgs. 
// Provides step function.
using System;
using System.Collections.Generic;
using System.Threading;

namespace MorgSim
{
    class PetriDish
    {
        // All living Morgs
        public List<Morg> allMorgs;

        // Constructor: Instantiate board and list of all morgs.
        public PetriDish()
        {
            allMorgs = new List<Morg>();
            int[,] board = new int[50, 50];
        }

        // Add/Remove methods for allMorgs list.
        public void AddMorg(Morg aMorg) { allMorgs.Add(aMorg); }
        public void RemoveMorg(Morg deadMorg) { allMorgs.Remove(deadMorg); }

        // Step method provides main functionality for simulator.
        public void Step(Morg m)
        {
            if (!m.IsDead)
            {
                Search(m);
                m.PerformMove();
                m.PerformFeed();
                m.NotifyObservers();
            }  
        }

        // Search method: Use list of all morgs to check if given morg is close to another.
        public void Search(Morg m)
        {
            int xValue;
            int yValue;
            foreach (Morg morg in allMorgs)
            {
                xValue = m.Location.X - morg.Location.X;
                yValue = m.Location.Y - morg.Location.Y;

                // If morg is within 10 spaces try to set it as prey
                if (((xValue <= 5) && (xValue >= -5)) && ((yValue <= 5) && (yValue >= -5))) { m.SetPrey(morg); }
            }
        }

        // SuddenDeathSearch method: called if the simulation has gone over 150 cycles.
        // Lets all morgs know the location of all other morgs.
        public void SuddenDeathSearch(Morg m)
        {
            foreach (Morg morg in allMorgs) { m.SetPrey(morg); }
        }

        // CanEatEachOther method: called each cycle.
        // Returns true if any morgs remaining can each any other morgs.
        public bool CanEatEachOther()
        {
            foreach (Morg predMorg in allMorgs)
            {
                foreach(Morg potentialPrey in allMorgs)
                {
                    // If the two morgs are not the same morg and if predMorg can eat potentialPrey.
                    if ((predMorg != potentialPrey) && (predMorg.CanEat(potentialPrey))) { return true; }
                }
            }
            return false;
        }
    }
}
