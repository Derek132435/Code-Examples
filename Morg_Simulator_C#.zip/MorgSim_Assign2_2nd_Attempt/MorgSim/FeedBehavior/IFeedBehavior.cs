﻿// Derek Edwards
// IFeedBehavior: feed behavior interface.
namespace MorgSim
{
    interface IFeedBehavior
    {
        void feed(ref bool feedSuccessful, string food, int chanceOfSuccess);
    }
}
