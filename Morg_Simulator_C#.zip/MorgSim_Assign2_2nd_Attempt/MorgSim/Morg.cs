﻿// Derek Edwards
// Morg class: superclass for morgs
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace MorgSim
{
    class Morg : IObserver, ISubject
    {
        // Member Variables.
        private IMoveBehavior moveBehavior;
        private IFeedBehavior feedBehavior;
        private List<Morg> predators;
        private List<string> edibleMorgs;
        private Point location;
        private Morg prey;
        private Point preyLocation;
        private bool hasPrey = false;
        private bool feedSuccessful = false;
        private bool isDead = false;
        private string direction;
        private int speed = 0;
        private string type;
        private List<int> randomNumbers;

        // RemoveRandomNumber method: remove the first number after each use of list.
        public void RemoveRandomNumber() { randomNumbers.RemoveAt(0); }

        // AddEdibleMorg method: add Morg to edible Morg List.
        public void AddEdibleMorg(string aMorgType) { edibleMorgs.Add(aMorgType); }

        // Get/Set methods: for morg member variables.
        public bool IsDead { get { return isDead; } set { isDead = value; } }
        public string Type { get { return type; } set { type = value; } }
        public Point Location { get { return location; } set { location = value; } }

        // PreyDead method: assigns a morg's prey's status to dead after being eaten.
        public void PreyDead()
        {
            hasPrey = false;
            prey = null;
        }

        // Morg default constructor
        public Morg()
        {
            // Instantiate predators, edibleMorgs, and randomNumbers lists.
            predators = new List<Morg>();
            edibleMorgs = new List<string>();
            randomNumbers = new List<int>();
            randomNumbers.AddRange(Enumerable.Range(0, 2000).OrderBy(x => Guid.NewGuid()).Take(450));

            // Choose random spawn location.
            int X = randomNumbers[0] % 50;
            RemoveRandomNumber();
            int Y = randomNumbers[0] % 50;
            RemoveRandomNumber();
            location = new Point(X, Y);

            // Set random speed 1-4.
            int morgSpeed = randomNumbers[0] % 5;
            RemoveRandomNumber();
            if (morgSpeed != 0) { speed = morgSpeed; }
            else { speed = 1; }
        }

        // Move/Feed Behavior methods.
        public void setMoveBehavior(IMoveBehavior move) { moveBehavior = move; }
        public void setFeedBehavior(IFeedBehavior feed) { feedBehavior = feed; }

        // PerformMove method: If morg has prey move towards it, otherwise move randomly.
        public void PerformMove()
        {
            if (hasPrey) { Console.WriteLine("{0} Attempts to Move Towards {1}", type, prey.Type); }
            else { Console.WriteLine("{0} Attempts to Move Randomly {1}...", type, direction); }
            Console.Write(type);
            moveBehavior.move(ref location, speed, direction);

            // If Morg does not have prey, call update to assign a random direction.
            if(!hasPrey) { Update(preyLocation); }
        }


        // PerformFeed method: If has prey, prey is close, and prey is not already dead, try to eat it
        public void PerformFeed()
        {
            if (hasPrey)
            {
                if (((location.X - preyLocation.X) <= 2) && ((location.Y - preyLocation.Y) <= 2) && (!prey.IsDead))
                {
                    Console.Write(type);

                    // Call feedBehavior.feed with random number for chance of success calculation
                    feedBehavior.feed(ref feedSuccessful, prey.Type, randomNumbers[0]);
                    RemoveRandomNumber();

                    // If feed was successful set prey's status to dead and let all current predators know
                    if (feedSuccessful)
                    {
                        prey.IsDead = true;
                        foreach (Morg morg in prey.predators) { morg.PreyDead(); }
                        feedSuccessful = false;
                    }
                }
            }
        }


        // ISubject Interface Implementation.
        // RegisterObserver method: register a new observer.
        public void RegisterObserver(Morg pred) { predators.Add(pred); }
        // RemoveObserver method: remove a currently registered observer.
        public void RemoveObserver(Morg pred) { predators.Remove(pred); }
        // NotifyObservers method: send current cocation To all observers.
        public void NotifyObservers() { foreach (Morg pred in predators) { pred.Update(location); } }


        // IObserver Interface Implementation.
        // Update method: receive prey's location from prey and set preyLocation and direction variables.
        public void Update(Point preyLoc)
        {
            // If morg has prey set its direction to move toward it.
            preyLocation = preyLoc;
            if (hasPrey)
            {
                if (location.Y < preyLocation.Y) { direction = "Up"; }
                else if (location.Y > preyLocation.Y) { direction = "Down"; }
                else if (location.X < preyLocation.X) { direction = "Right"; }
                else { direction = "Left"; }
            }
            // If morg does not have prey generate a random direction.
            else
            {
                int dir = randomNumbers[0] % 4;
                RemoveRandomNumber();
                if (dir == 3) { direction = "Up"; }
                else if (dir == 2) { direction = "Down"; }
                else if (dir == 1) { direction = "Left"; }
                else { direction = "Right"; }
            }
        }

        // SetPrey method: attempt to set given prey.
        public void SetPrey(Morg thePrey)
        {
            // If morg is not the same as this, and morg does not already have prey,
            // and if the prey is alive.
            if ((this != thePrey) && (!hasPrey) && (!thePrey.IsDead))
            {
                // If prey is in the morgs edible types list, set it.
                if (CanEat(thePrey))
                {
                    hasPrey = true;
                    prey = thePrey;
                    // The prey registers morg as an observer
                    thePrey.RegisterObserver(this);
                    Console.WriteLine("{0} Has Spotted {1}", type, thePrey.Type);
                }
            }
        }

        // CanEat method: if prey's type is within the morgs edible type list, return true
        public bool CanEat(Morg thePrey)
        {
            foreach (string preyType in edibleMorgs) { if (thePrey.Type == preyType) { return true; } }
            return false;
        }
    }
}
