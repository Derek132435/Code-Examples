﻿// Derek Edwards
// Simulation class: creates a PetriDish and cycles through step method until
// complete, then prints out answers.
using System;
using System.Linq;

/*------------------------------------------------------------------------------------------------------
SIMULATION RULES:
Simulation runs through up to 200 cycles of Morgs hunting/eating each other
After 150 cycles, if simulation is not done, SuddenDeathSearch is called, informing all Morgs of all other morgs
If a Morg is the last alive, it is declared the victor
If any prey evades predators for full 200 cycles or remaining morgs cannot each each other it is a tie
--------------------------------------------------------------------------------------------------------*/

namespace MorgSim
{
    class Simulation
    {
        private PetriDish Arena;

        public Simulation()
        {
            Arena = new PetriDish();

            // Opens a file and reads morgs from it line by line until end.
            MorgReader reader = new MorgReader(new FileReader("Morgs.txt"));
            Morg m = reader.ReadMorg();

            // Read a line from file, convert to a Morg, Add morg to allMorgs list.
            while (m != null)
            {
                Arena.AddMorg(m);
                m = reader.ReadMorg();
            }
            reader.Close();
            
            // Cycle 200 times through process of checking game conditions and calling step function.
            for (int i = 0; i < 200; i++)
            {
                // If any of the remaining Morgs can eat another remaining Morg.
                if (Arena.CanEatEachOther())
                {
                    foreach (Morg morg in Arena.allMorgs.ToList())
                    {
                        // If simulation runs too long...SUDDEN DEATH COMBAT!!! (Lets all morgs know where all other morgs are).
                        if (i >= 150) { Arena.SuddenDeathSearch(morg); }

                        // If there is one morg or less left, break.
                        if (Arena.allMorgs.Count() <= 1) { break; }

                        // If the current morg is flagged as dead, remove it.
                        if (morg.IsDead) { Arena.RemoveMorg(morg); }

                        // Call the step method for current morg.
                        Arena.Step(morg);
                    }
                }
            }
            // Output of simulation based on number of remaining morgs.
            if (Arena.allMorgs.Count() <= 0) { throw new Exception("Error: All Morgs Dead"); }
            else if (Arena.allMorgs.Count() == 1) { Console.WriteLine("{0} Is Victorious!", Arena.allMorgs.First().Type); }
            else
            {
                Console.WriteLine("It's a Tie! Below are the survivors: ");
                foreach (Morg aMorg in Arena.allMorgs)
                {
                    Console.WriteLine(aMorg.Type);
                }
            }
                
        }
    }
}