﻿// Derek Edwards
// Program class: contains main method, creates and starts a simulation.
using System;
using System.Collections.Generic;
using System.Linq;

namespace MorgSim
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create and start Simulation.
            Simulation sim = new Simulation();

            // Debug: wait for keystroke to exit program.
            Console.WriteLine("Press Any Key To Exit...");
            Console.ReadKey();
        }

    }
}
