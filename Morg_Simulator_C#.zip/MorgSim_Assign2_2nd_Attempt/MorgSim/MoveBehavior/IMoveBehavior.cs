﻿// Derek Edwards
// IMoveBehavior: move behavior interface.
using System.Drawing;

namespace MorgSim
{
    interface IMoveBehavior
    {
        void move(ref Point location, int speed, string direction);
    }
}
