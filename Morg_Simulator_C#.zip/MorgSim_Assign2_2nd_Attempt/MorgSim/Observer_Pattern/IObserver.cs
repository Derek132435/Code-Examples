﻿// Derek Edwards
// IObserver: observer interface
using System.Drawing;

namespace MorgSim
{
    interface IObserver
    {
        void Update(Point preyLoc);
    }
}